﻿namespace FlowOps.Contracts.Response
{
    public sealed record PlanResponse
    (
        string Code,
        decimal Price
    );
}
