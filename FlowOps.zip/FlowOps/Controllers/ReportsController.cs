﻿using FlowOps.Contracts.Response;
using FlowOps.Infrastructure.Sql.Reporting;
using FlowOps.Reports.Models;
using FlowOps.Reports.Stores;
using Microsoft.AspNetCore.Mvc;

namespace FlowOps.Controllers
{
    [ApiController]
    [Route("api/reports")]
    public class ReportsController : ControllerBase
    {
        private readonly IReportingStore _store;
        public ReportsController(IReportingStore store)
        {
            _store = store;
        }
        // path postman : GET http://localhost:32768/api/reports/customers/{customerId}
        [HttpGet("customers/{customerId:guid}")]
        public ActionResult<CustomerReport> Get(Guid customerId){
            if (_store.TryGet(customerId, out var report) && report is not null)
            {
                return Ok(report);
            }
            return NotFound();
        }
        [HttpGet("customers/{customerId:guid}/active-subscriptions")]
        public IActionResult GetActiveSubscriptionIds(Guid customerId)
        {
            var report = _store.GetOrAdd(customerId);
            var ids = report.ActiveSubscriptionIds.OrderBy(id => id).ToArray();
            return Ok(ids);
        }
        [HttpGet("sql/customers/{customerId:guid}")]
        public async Task<ActionResult<CustomerReportSqlResponse>> GetCustomerReportSql(
            Guid customerId,
            [FromServices] ISqlReportingQueries queries,
            CancellationToken ct)
        {
            var result = await queries.GetCustomerReportAsync(customerId, ct);
            if(result is null)
            {
                throw new KeyNotFoundException($"Customer {customerId} not found in SQL report.");
            }
            return Ok(result);
        }
        [HttpGet("sql/customers/{customerId:guid}/active-subscriptions")]
        public async Task<ActionResult<IEnumerable<Guid>>> GetActiveSubscriptionIdsSql(
            Guid customerId,
            [FromServices] ISqlReportingQueries queries,
            CancellationToken ct)
        {
            var ids = await queries.GetActiveSubscriptionIdsAsync(customerId, ct);
            return Ok(ids);
        }
    }
}
