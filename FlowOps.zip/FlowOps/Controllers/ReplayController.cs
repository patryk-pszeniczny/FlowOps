﻿using FlowOps.Events;
using FlowOps.Reports.Stores;
using FlowOps.Services.Replay;
using FlowOps.Services.Reporting;
using Microsoft.AspNetCore.Mvc;

namespace FlowOps.Controllers
{
    [ApiController]
    [Route("api/replay")]
    public class ReplayController : ControllerBase
    {
        private readonly EventRecorder _recorder;
        private readonly IReportingHandler _reporting;
        private readonly IReportingStore _store;

        public ReplayController(
            EventRecorder recorder, 
            IReportingHandler reporting, 
            IReportingStore store)
        {
            _recorder = recorder;
            _reporting = reporting;
            _store = store;
        }
        [HttpGet("events")]
        public ActionResult<IEnumerable<object>> GetEvents()
        {
            var snapshot = _recorder.Snapshot()
                .OrderBy(e => e.OccurredOn)
                .ThenBy(e => e.Version)
                .Select(e => new
                {
                    type = e.GetType().Name,
                    e.Id,
                    e.OccurredOn,
                    e.Version
                });
            return Ok(snapshot);
        }
        [HttpPost("reports/rebuild")]
        public async Task<IActionResult> RebuildReports(CancellationToken ct)
        {
            if(_store is InMemoryReportingStore mem)
            {
                mem.Clear();
            }
            var ordered = _recorder.Snapshot()
                .OrderBy(e => e.OccurredOn)
                .ThenBy(e => e.Version);
            foreach (var ev in ordered)
            {
                switch (ev)
                {
                    case SubscriptionActivatedEvent a:
                        await _reporting.On(a, ct);
                        break;
                    case SubscriptionCancelledEvent c:
                        await _reporting.On(c, ct);
                        break;
                    case InvoiceIssuedEvent i:
                        await _reporting.On(i, ct);
                        break;
                    case InvoicePaidEvent p:
                        await _reporting.On(p, ct);
                        break;
                    case SubscriptionSuspendedEvent s:
                        await _reporting.On(s, ct);
                        break;
                    case SubscriptionResumedEvent r:
                        await _reporting.On(r, ct);
                        break;
                }
            }
            return Ok(new
            {
                message = "Reports rebuild from recorded events."
            });
        }
    }
}
